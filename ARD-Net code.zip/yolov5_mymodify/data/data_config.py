def get_train_data():
    return "/root/anquanmao/data/"
